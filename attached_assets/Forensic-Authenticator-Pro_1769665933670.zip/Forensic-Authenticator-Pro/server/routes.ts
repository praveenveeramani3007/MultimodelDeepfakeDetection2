import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { api } from "@shared/routes";
import { z } from "zod";
import PDFDocument from "pdfkit";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Integrations
  await setupAuth(app);
  registerAuthRoutes(app);
  registerChatRoutes(app);

  // === Reports API ===

  app.get(api.reports.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const reports = await storage.getReports(userId);
    res.json(reports);
  });

  app.get(api.reports.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const report = await storage.getReport(Number(req.params.id));
    if (!report) return res.sendStatus(404);
    res.json(report);
  });

  app.post(api.reports.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.reports.create.input.parse(req.body);
      const userId = (req.user as any).claims.sub;
      
      const report = await storage.createReport({
        title: input.title,
        type: input.type,
        fileUrl: input.fileData ? "simulated_upload_url" : undefined, // In real app, upload to S3/blob
        userId,
        status: "pending"
      });

      // Simulate immediate analysis trigger
      simulateAnalysis(report.id, input.type);

      res.status(201).json(report);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.reports.downloadCertificate.path, async (req, res) => {
    // if (!req.isAuthenticated()) return res.sendStatus(401); 
    // Allow public download if they have the link? Or strict? strict for government.
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const report = await storage.getReport(Number(req.params.id));
    if (!report || report.status !== 'completed') return res.sendStatus(404);

    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=certificate-${report.id}.pdf`);
    
    doc.pipe(res);

    // Certificate Design
    doc.fontSize(25).text('OFFICIAL FORENSIC REPORT', 100, 100);
    doc.fontSize(15).text(`Report ID: ${report.id}`, 100, 150);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 100, 170);
    doc.text(`Type: ${report.type.toUpperCase()}`, 100, 190);
    
    doc.moveDown();
    doc.fontSize(20).text('ANALYSIS RESULT', 100, 250);
    
    const isFake = (report.fakeProbability || 0) > 50;
    doc.fontSize(15).fillColor(isFake ? 'red' : 'green')
       .text(`VERDICT: ${isFake ? 'FAKE / MANIPULATED' : 'AUTHENTIC / REAL'}`, 100, 280);
    
    doc.fillColor('black').text(`Confidence Score: ${report.fakeProbability}%`, 100, 310);
    
    doc.moveDown();
    doc.fontSize(12).text('Details:', 100, 350);
    const details = report.details as any;
    if (details) {
       doc.text(JSON.stringify(details, null, 2));
    }

    doc.moveDown(5);
    doc.text('_________________________', 100, 600);
    doc.text('Authorized Signature', 100, 620);
    doc.text('Court Forensic Department', 100, 640);

    doc.end();
  });

  app.get(api.analysis.logs.path, async (req, res) => {
    const logs = await storage.getAnalysisLogs(Number(req.params.id));
    res.json(logs);
  });

  return httpServer;
}

// Simulated Analysis Engine
async function simulateAnalysis(reportId: number, type: string) {
  const steps = [
    "Initializing forensic engine...",
    "Extracting metadata...",
    "Scanning for compression artifacts...",
    "Analyzing noise patterns...",
    "Checking for adversarial perturbations...",
    "Verifying consistency...",
    "Generating final verdict..."
  ];

  await storage.updateReport(reportId, { status: "processing" });

  for (const step of steps) {
    await new Promise(r => setTimeout(r, 1500)); // Simulate delay
    await storage.addAnalysisLog(reportId, step, "completed");
  }

  const isFake = Math.random() > 0.5;
  const probability = isFake ? Math.floor(Math.random() * 20 + 80) : Math.floor(Math.random() * 20); // 80-99 or 0-19

  await storage.updateReport(reportId, {
    status: "completed",
    fakeProbability: probability,
    details: {
      engine_version: "v2.5.0-alpha",
      artifacts_detected: isFake ? ["inconsistent_lighting", "warping_trace", "gan_fingerprint"] : [],
      metadata_integrity: isFake ? "compromised" : "valid",
      scan_duration: "12.4s"
    }
  });
}
