import { 
  users, type User, type InsertUser,
  reports, type Report, type InsertReport,
  analysisLogs, type AnalysisLog
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { authStorage, type IAuthStorage } from "./replit_integrations/auth/storage";
import { chatStorage, type IChatStorage } from "./replit_integrations/chat/storage";

export interface IStorage extends IAuthStorage, IChatStorage {
  // Reports
  createReport(report: InsertReport & { userId?: string }): Promise<Report>;
  getReport(id: number): Promise<Report | undefined>;
  getReports(userId?: string): Promise<Report[]>;
  updateReport(id: number, updates: Partial<Report>): Promise<Report>;
  deleteReport(id: number): Promise<void>;
  
  // Analysis Logs
  addAnalysisLog(reportId: number, step: string, status: string): Promise<AnalysisLog>;
  getAnalysisLogs(reportId: number): Promise<AnalysisLog[]>;
}

export class DatabaseStorage implements IStorage {
  // Auth Delegates
  getUser = authStorage.getUser;
  upsertUser = authStorage.upsertUser;

  // Chat Delegates
  getConversation = chatStorage.getConversation;
  getAllConversations = chatStorage.getAllConversations;
  createConversation = chatStorage.createConversation;
  deleteConversation = chatStorage.deleteConversation;
  getMessagesByConversation = chatStorage.getMessagesByConversation;
  createMessage = chatStorage.createMessage;

  // Reports Implementation
  async createReport(report: InsertReport & { userId?: string }): Promise<Report> {
    const [newReport] = await db.insert(reports).values(report).returning();
    return newReport;
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report;
  }

  async getReports(userId?: string): Promise<Report[]> {
    if (!userId) return [];
    return db.select().from(reports)
      .where(eq(reports.userId, userId))
      .orderBy(desc(reports.createdAt));
  }

  async updateReport(id: number, updates: Partial<Report>): Promise<Report> {
    const [updated] = await db.update(reports)
      .set(updates)
      .where(eq(reports.id, id))
      .returning();
    return updated;
  }

  async deleteReport(id: number): Promise<void> {
    await db.delete(reports).where(eq(reports.id, id));
  }

  // Analysis Logs Implementation
  async addAnalysisLog(reportId: number, step: string, status: string): Promise<AnalysisLog> {
    const [log] = await db.insert(analysisLogs)
      .values({ reportId, step, status })
      .returning();
    return log;
  }

  async getAnalysisLogs(reportId: number): Promise<AnalysisLog[]> {
    return db.select().from(analysisLogs)
      .where(eq(analysisLogs.reportId, reportId))
      .orderBy(analysisLogs.timestamp);
  }
}

export const storage = new DatabaseStorage();
