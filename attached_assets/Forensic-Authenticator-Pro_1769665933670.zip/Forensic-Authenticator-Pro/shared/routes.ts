import { z } from 'zod';
import { insertReportSchema, reports, analysisLogs } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  reports: {
    list: {
      method: 'GET' as const,
      path: '/api/reports',
      responses: {
        200: z.array(z.custom<typeof reports.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/reports/:id',
      responses: {
        200: z.custom<typeof reports.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/reports',
      input: z.object({
        title: z.string(),
        type: z.enum(['image', 'video', 'audio', 'live']),
        fileName: z.string().optional(),
        fileData: z.string().optional(), // Base64 if small, otherwise upload endpoint
      }),
      responses: {
        201: z.custom<typeof reports.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/reports/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
    downloadCertificate: {
      method: 'GET' as const,
      path: '/api/reports/:id/certificate',
      responses: {
        200: z.any(), // Blob/PDF
        404: errorSchemas.notFound,
      },
    }
  },
  analysis: {
    start: {
      method: 'POST' as const,
      path: '/api/reports/:id/analyze',
      responses: {
        200: z.object({ message: z.string() }),
        404: errorSchemas.notFound,
      },
    },
    logs: {
      method: 'GET' as const,
      path: '/api/reports/:id/logs',
      responses: {
        200: z.array(z.custom<typeof analysisLogs.$inferSelect>()),
      },
    }
  }
};

// ============================================
// REQUIRED: buildUrl helper
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type ReportInput = z.infer<typeof api.reports.create.input>;
export type ReportResponse = z.infer<typeof api.reports.get.responses[200]>;
