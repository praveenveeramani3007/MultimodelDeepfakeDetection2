import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

// === TABLE DEFINITIONS ===

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(), // 'image', 'video', 'audio', 'live'
  status: text("status").notNull().default("pending"), // 'pending', 'processing', 'completed', 'failed'
  fakeProbability: integer("fake_probability"), // 0-100
  details: jsonb("details"), // Detailed analysis results
  fileUrl: text("file_url"),
  userId: text("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const analysisLogs = pgTable("analysis_logs", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").references(() => reports.id),
  step: text("step").notNull(),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// === RELATIONS ===
export const reportsRelations = relations(reports, ({ one, many }) => ({
  user: one(users, {
    fields: [reports.userId],
    references: [users.id],
  }),
  logs: many(analysisLogs),
}));

export const analysisLogsRelations = relations(analysisLogs, ({ one }) => ({
  report: one(reports, {
    fields: [analysisLogs.reportId],
    references: [reports.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertReportSchema = createInsertSchema(reports).omit({ 
  id: true, 
  createdAt: true, 
  userId: true, // Set by backend
  status: true,
  fakeProbability: true,
  details: true
});

// === EXPLICIT API CONTRACT TYPES ===

// Base types
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

// Request types
export type CreateReportRequest = {
  title: string;
  type: 'image' | 'video' | 'audio' | 'live';
  fileData?: string; // Base64 for now, or handled via multipart/form-data separately
  fileName?: string;
};

export type UpdateReportRequest = Partial<Report>;

// Response types
export type ReportResponse = Report;
export type ReportsListResponse = Report[];

export type AnalysisLog = typeof analysisLogs.$inferSelect;
