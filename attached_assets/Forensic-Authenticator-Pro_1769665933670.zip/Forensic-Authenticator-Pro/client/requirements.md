## Packages
framer-motion | Complex animations for the "scanning" effects and page transitions
recharts | Data visualization for the dashboard stats
date-fns | Date formatting for reports
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
  display: ["'Orbitron'", "sans-serif"],
}
