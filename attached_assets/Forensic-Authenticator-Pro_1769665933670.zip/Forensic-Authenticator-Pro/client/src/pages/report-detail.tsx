import { Layout } from "@/components/layout";
import { useReport, useAnalysisLogs, useDeleteReport } from "@/hooks/use-reports";
import { useRoute, useLocation } from "wouter";
import { 
  Loader2, 
  CheckCircle2, 
  XCircle, 
  Download, 
  Trash2, 
  MessageSquare,
  ShieldAlert,
  ShieldCheck,
  Cpu
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

export default function ReportDetail() {
  const [match, params] = useRoute("/reports/:id");
  const id = parseInt(params?.id || "0");
  const { data: report, isLoading } = useReport(id);
  const { data: logs } = useAnalysisLogs(id);
  const deleteReport = useDeleteReport();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-primary animate-spin mx-auto" />
            <p className="text-muted-foreground font-mono">Retrieving secure data...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!report) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-2">Report Not Found</h1>
            <Button onClick={() => setLocation("/reports")}>Back to Archive</Button>
          </div>
        </div>
      </Layout>
    );
  }

  const handleDelete = async () => {
    if (confirm("Are you sure you want to delete this forensic record? This action cannot be undone.")) {
      await deleteReport.mutateAsync(id);
      setLocation("/reports");
    }
  };

  const isFake = (report.fakeProbability || 0) > 50;
  const confidenceColor = isFake ? "text-red-500" : "text-green-500";
  const statusColor = report.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400';

  return (
    <Layout>
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/10 pb-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Badge className={`${statusColor} border-0 uppercase tracking-widest`}>
                {report.status}
              </Badge>
              <span className="text-muted-foreground font-mono text-sm">ID: #{report.id.toString().padStart(6, '0')}</span>
            </div>
            <h1 className="text-3xl font-display font-bold text-white text-glow">{report.title}</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Created {new Date(report.createdAt!).toLocaleString()} • Type: <span className="uppercase">{report.type}</span>
            </p>
          </div>
          <div className="flex gap-3">
             <Button variant="outline" className="border-white/10 hover:bg-white/5" onClick={() => alert("Certificate generation simulated")}>
              <Download className="w-4 h-4 mr-2" />
              Certificate
            </Button>
            <Button variant="destructive" size="icon" onClick={handleDelete}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column - Preview & Result */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Visual Preview */}
            <Card className="glass-card border-white/10 overflow-hidden">
              <CardContent className="p-0 relative aspect-video bg-black/50 flex items-center justify-center">
                {report.fileUrl ? (
                   report.type === 'video' ? (
                     <video src={report.fileUrl} controls className="max-h-full max-w-full" />
                   ) : report.type === 'audio' ? (
                     <div className="text-center p-10">
                       <ShieldAlert className="w-20 h-20 text-primary mb-4 mx-auto" />
                       <audio src={report.fileUrl} controls />
                     </div>
                   ) : (
                     <img src={report.fileUrl} alt="Analyzed Media" className="max-h-full max-w-full object-contain" />
                   )
                ) : (
                  <div className="text-center p-10 text-muted-foreground">
                    <ShieldCheck className="w-20 h-20 mb-4 mx-auto opacity-20" />
                    <p>Artifact Securely Stored</p>
                  </div>
                )}
                
                {/* Overlay Scan Effect if Processing */}
                {report.status === 'processing' && (
                  <>
                    <div className="absolute inset-0 bg-primary/10 z-10" />
                    <div className="scan-line z-20" />
                    <div className="absolute bottom-4 left-4 z-20 bg-black/80 px-3 py-1 rounded text-primary font-mono text-sm animate-pulse">
                      ANALYZING PIXEL DATA...
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Analysis Result */}
            {report.status === 'completed' && (
              <Card className={`glass-card border-l-4 ${isFake ? 'border-l-red-500' : 'border-l-green-500'}`}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-primary" />
                    AI Verdict
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className={`text-4xl font-display font-bold ${confidenceColor}`}>
                        {isFake ? "DEEPFAKE DETECTED" : "AUTHENTIC MEDIA"}
                      </h2>
                      <p className="text-muted-foreground mt-1">
                        Confidence Score: <span className="text-foreground font-bold">{report.fakeProbability}%</span>
                      </p>
                    </div>
                    <div className="h-24 w-24 rounded-full border-4 border-white/10 flex items-center justify-center relative">
                      <div className="absolute inset-0 rounded-full border-4 border-t-primary animate-spin opacity-20" />
                      {isFake ? <XCircle className="w-12 h-12 text-red-500" /> : <CheckCircle2 className="w-12 h-12 text-green-500" />}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Visual Artifacts</span>
                        <span className={isFake ? "text-red-400" : "text-green-400"}>
                          {isFake ? "Detected" : "Clean"}
                        </span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-primary" style={{ width: `${Math.random() * 100}%` }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Audio Consistency</span>
                        <span>Analysing...</span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-secondary" style={{ width: '60%' }} />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Logs & Chat */}
          <div className="space-y-6">
            <Card className="glass-card border-white/10 h-[400px] flex flex-col">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono uppercase tracking-widest text-muted-foreground">System Logs</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto space-y-4 font-mono text-xs p-4">
                {logs?.map((log, idx) => (
                  <motion.div 
                    key={log.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex gap-3 border-l border-white/10 pl-3 pb-2"
                  >
                    <div className="text-muted-foreground min-w-[60px]">
                      {new Date(log.timestamp!).toLocaleTimeString([], { hour12: false })}
                    </div>
                    <div>
                      <span className={`uppercase font-bold ${
                        log.status === 'completed' ? 'text-green-400' :
                        log.status === 'processing' ? 'text-yellow-400' : 'text-red-400'
                      }`}>[{log.status}]</span> {log.step}
                    </div>
                  </motion.div>
                ))}
                {report.status === 'pending' && (
                  <div className="flex gap-3 pl-3 animate-pulse">
                     <div className="text-primary">{'>'}_</div>
                     <div className="text-primary">Initializing Neural Engine...</div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="glass-card border-primary/20 bg-primary/5">
              <CardContent className="p-6 text-center space-y-4">
                <MessageSquare className="w-10 h-10 text-primary mx-auto" />
                <div>
                  <h3 className="font-bold text-lg text-white">Need Expert Opinion?</h3>
                  <p className="text-sm text-muted-foreground">Ask our AI Forensics Assistant to interpret these results.</p>
                </div>
                <Button className="w-full bg-primary text-primary-foreground font-bold" onClick={() => setLocation("/chat")}>
                  Open Secure Chat
                </Button>
              </CardContent>
            </Card>
          </div>

        </div>
      </div>
    </Layout>
  );
}
