import { Layout } from "@/components/layout";
import { useState, useRef } from "react";
import { useCreateReport, useStartAnalysis } from "@/hooks/use-reports";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, Camera, FileAudio, FileVideo, Image as ImageIcon, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

export default function AnalysisPage() {
  const [activeTab, setActiveTab] = useState("image");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const createReport = useCreateReport();
  const startAnalysis = useStartAnalysis();
  const [, setLocation] = useLocation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file && activeTab !== "live") return;
    if (!title) return;

    try {
      // In a real app, we'd upload to S3/Cloud storage first.
      // Here we simulate by sending base64 for small files or just metadata
      const reader = new FileReader();
      
      const processSubmission = async (base64Data?: string) => {
        const report = await createReport.mutateAsync({
          title,
          type: activeTab as 'image' | 'video' | 'audio' | 'live',
          fileName: file?.name || 'Live Feed Capture',
          fileData: base64Data, // Be careful with large payloads in prod
        });
        
        // Automatically start analysis
        startAnalysis.mutate(report.id);
        
        // Redirect to report detail to watch progress
        setLocation(`/reports/${report.id}`);
      };

      if (file) {
        reader.readAsDataURL(file);
        reader.onloadend = () => processSubmission(reader.result as string);
      } else {
        processSubmission(); // Live mode
      }

    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-white text-glow mb-2">New Investigation</h1>
          <p className="text-muted-foreground">Select artifact type and upload for deep neural analysis.</p>
        </div>

        <Tabs defaultValue="image" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-4 bg-white/5 border border-white/10 p-1 rounded-xl">
            <TabsTrigger value="image" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <ImageIcon className="w-4 h-4 mr-2" /> Image
            </TabsTrigger>
            <TabsTrigger value="video" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <FileVideo className="w-4 h-4 mr-2" /> Video
            </TabsTrigger>
            <TabsTrigger value="audio" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <FileAudio className="w-4 h-4 mr-2" /> Audio
            </TabsTrigger>
            <TabsTrigger value="live" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Camera className="w-4 h-4 mr-2" /> Live Feed
            </TabsTrigger>
          </TabsList>

          <Card className="glass-card border-white/10 overflow-hidden">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-lg font-medium">Case Title / Reference ID</Label>
                  <Input 
                    id="title" 
                    placeholder="e.g. Evidence #4492-B" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="bg-white/5 border-white/10 focus:border-primary/50 h-12 text-lg"
                    required
                  />
                </div>

                {activeTab !== 'live' ? (
                  <div className="border-2 border-dashed border-white/20 rounded-xl p-10 text-center hover:border-primary/50 hover:bg-white/5 transition-all cursor-pointer relative group"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept={
                        activeTab === 'image' ? "image/*" :
                        activeTab === 'video' ? "video/*" :
                        "audio/*"
                      }
                      onChange={handleFileChange}
                    />
                    
                    {preview ? (
                      <div className="relative w-full h-64 bg-black/50 rounded-lg overflow-hidden flex items-center justify-center">
                        {activeTab === 'image' && <img src={preview} alt="Preview" className="h-full object-contain" />}
                        {activeTab === 'video' && <video src={preview} className="h-full object-contain" controls />}
                        {activeTab === 'audio' && <div className="text-4xl text-primary"><FileAudio /></div>}
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <p className="text-white font-medium">Click to change file</p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mx-auto text-muted-foreground group-hover:text-primary group-hover:scale-110 transition-all duration-300">
                          <Upload className="w-10 h-10" />
                        </div>
                        <div>
                          <p className="text-lg font-medium">Drop artifact here or click to upload</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Supports {activeTab === 'image' ? 'JPG, PNG, WEBP' : activeTab === 'video' ? 'MP4, MOV, AVI' : 'MP3, WAV, M4A'}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden border border-white/10">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center space-y-4">
                        <Camera className="w-16 h-16 mx-auto text-primary animate-pulse" />
                        <p className="text-muted-foreground">Camera feed simulation active</p>
                        <div className="inline-block px-3 py-1 bg-red-500/20 text-red-500 rounded text-xs font-bold uppercase animate-pulse">
                          LIVE REC
                        </div>
                      </div>
                    </div>
                    {/* Simulated Scan Lines */}
                    <div className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 bg-[length:100%_2px,3px_100%] pointer-events-none" />
                    <div className="scan-line" />
                  </div>
                )}

                <div className="flex justify-end pt-4">
                  <Button 
                    type="submit" 
                    size="lg" 
                    disabled={createReport.isPending || (!file && activeTab !== 'live') || !title}
                    className="bg-primary text-primary-foreground font-bold text-lg px-8 hover:bg-primary/90 shadow-[0_0_20px_rgba(6,182,212,0.4)]"
                  >
                    {createReport.isPending ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Initiating...
                      </>
                    ) : (
                      <>
                        INITIATE ANALYSIS
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </Tabs>
      </div>
    </Layout>
  );
}
