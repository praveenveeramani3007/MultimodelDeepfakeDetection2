import { Layout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { useReports } from "@/hooks/use-reports";
import { StatCard } from "@/components/stat-card";
import { 
  Activity, 
  FileCheck, 
  AlertTriangle, 
  Clock,
  ArrowRight
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from "recharts";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: reports, isLoading } = useReports();

  const totalReports = reports?.length || 0;
  const completedReports = reports?.filter(r => r.status === 'completed').length || 0;
  const pendingReports = reports?.filter(r => r.status === 'pending').length || 0;
  const fakeReports = reports?.filter(r => (r.fakeProbability || 0) > 50).length || 0;
  
  const fakePercentage = totalReports > 0 ? Math.round((fakeReports / totalReports) * 100) : 0;

  const chartData = [
    { name: 'Authentic', value: totalReports - fakeReports, color: '#22c55e' }, // Green
    { name: 'Deepfake', value: fakeReports, color: '#ef4444' }, // Red
  ];

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-white text-glow">
              Command Center
            </h1>
            <p className="text-muted-foreground mt-1 font-mono text-sm">
              Welcome back, Officer {user?.lastName}. System Status: <span className="text-green-400">ONLINE</span>
            </p>
          </div>
          <Link href="/analysis">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(6,182,212,0.3)] font-semibold">
              <Activity className="w-4 h-4 mr-2" />
              New Analysis
            </Button>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard 
            title="Total Analyses" 
            value={totalReports} 
            icon={Activity} 
            description="Since last reset"
            delay={0.1}
          />
          <StatCard 
            title="Completed" 
            value={completedReports} 
            icon={FileCheck} 
            trend="up"
            trendValue="+12%"
            description="vs last week"
            delay={0.2}
          />
          <StatCard 
            title="Fake Detection" 
            value={`${fakePercentage}%`} 
            icon={AlertTriangle} 
            trend={fakePercentage > 20 ? "down" : "neutral"}
            trendValue="High Alert"
            description="Avg. confidence"
            delay={0.3}
          />
          <StatCard 
            title="Pending Queue" 
            value={pendingReports} 
            icon={Clock} 
            description="Processing now"
            delay={0.4}
          />
        </div>

        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Recent Activity List */}
          <Card className="lg:col-span-2 glass-card border-white/10">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-display tracking-wider">Recent Analyses</CardTitle>
              <Link href="/reports">
                <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover:bg-primary/10">
                  View All <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-white/5 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : reports && reports.length > 0 ? (
                <div className="space-y-4">
                  {reports.slice(0, 5).map((report, idx) => (
                    <motion.div 
                      key={report.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/5 hover:border-primary/30 hover:bg-white/10 transition-all group"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`
                          w-10 h-10 rounded-full flex items-center justify-center border
                          ${report.type === 'image' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : ''}
                          ${report.type === 'video' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' : ''}
                          ${report.type === 'audio' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' : ''}
                          ${report.type === 'live' ? 'bg-red-500/20 text-red-400 border-red-500/30' : ''}
                        `}>
                          {report.type === 'image' && 'IMG'}
                          {report.type === 'video' && 'VID'}
                          {report.type === 'audio' && 'AUD'}
                          {report.type === 'live' && 'LIVE'}
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">{report.title}</h4>
                          <p className="text-xs text-muted-foreground font-mono">
                            {new Date(report.createdAt!).toLocaleDateString()} • {report.type.toUpperCase()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                          report.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          report.status === 'processing' ? 'bg-yellow-500/20 text-yellow-400 animate-pulse' :
                          'bg-white/10 text-muted-foreground'
                        }`}>
                          {report.status}
                        </div>
                        <Button size="icon" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity">
                          <Link href={`/reports/${report.id}`}><ArrowRight className="w-4 h-4" /></Link>
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-muted-foreground">
                  No analysis records found. Start a new investigation.
                </div>
              )}
            </CardContent>
          </Card>

          {/* Stats Chart */}
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="font-display tracking-wider">Threat Distribution</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                    itemStyle={{ color: '#f8fafc' }}
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
              {/* Center Text */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none pb-8">
                <div className="text-center">
                  <span className="text-3xl font-bold font-display">{totalReports}</span>
                  <p className="text-xs text-muted-foreground uppercase">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </Layout>
  );
}
