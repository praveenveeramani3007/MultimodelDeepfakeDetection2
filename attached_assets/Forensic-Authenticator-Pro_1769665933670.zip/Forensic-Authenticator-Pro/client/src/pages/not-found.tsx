import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(6,182,212,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.1) 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }} 
      />
      
      <Card className="w-full max-w-md mx-4 glass-card border-destructive/50 shadow-[0_0_50px_rgba(239,68,68,0.2)]">
        <CardContent className="pt-6 text-center">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 bg-destructive/20 blur-xl rounded-full" />
              <AlertTriangle className="h-20 w-20 text-destructive relative z-10 animate-pulse" />
            </div>
          </div>
          
          <h1 className="text-5xl font-display font-bold text-white mb-2 tracking-widest">404</h1>
          <h2 className="text-xl font-bold text-destructive mb-4 uppercase tracking-wider">Access Error</h2>
          
          <p className="text-muted-foreground mb-8 font-mono text-sm">
            The requested sector does not exist or requires higher clearance. 
            This incident has been logged.
          </p>

          <Link href="/">
            <Button size="lg" variant="outline" className="w-full border-white/10 hover:bg-white/5 hover:text-white">
              Return to Command Center
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
