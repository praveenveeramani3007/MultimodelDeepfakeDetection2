import { Layout } from "@/components/layout";
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Send, Bot, User, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";

// Mock chat hook as the real one depends on complex backend streaming integration
// In a real implementation, you'd use the useChatStream or similar hook from replit_integrations
const useChatMock = () => {
  const [messages, setMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([
    { role: 'assistant', content: "I am the Forensic AI Assistant. I can help interpret analysis results, explain detection methodologies, or answer questions about deepfake technology. How can I assist you today?" }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (content: string) => {
    setMessages(prev => [...prev, { role: 'user', content }]);
    setIsLoading(true);
    
    // Simulate AI delay
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: "Based on the artifacts provided, the spectral analysis indicates inconsistencies in the pixel compression noise, which is a strong indicator of GAN-based manipulation. The audio track also shows lack of breathing pauses typical in synthetic speech generation." 
      }]);
      setIsLoading(false);
    }, 1500);
  };

  return { messages, sendMessage, isLoading };
};

export default function ChatPage() {
  const { user } = useAuth();
  const { messages, sendMessage, isLoading } = useChatMock();
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim()) return;
    sendMessage(input);
    setInput("");
  };

  return (
    <Layout>
      <div className="h-[calc(100vh-140px)] flex flex-col max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-display font-bold text-white text-glow">AI Assistant</h1>
          <p className="text-muted-foreground">Secure channel for forensic consultation.</p>
        </div>

        <Card className="flex-1 glass-card border-white/10 flex flex-col overflow-hidden">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6" ref={scrollRef}>
             <AnimatePresence initial={false}>
               {messages.map((msg, idx) => (
                 <motion.div 
                   key={idx}
                   initial={{ opacity: 0, y: 10 }}
                   animate={{ opacity: 1, y: 0 }}
                   className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                 >
                   {msg.role === 'assistant' && (
                     <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/50 flex items-center justify-center shrink-0">
                       <Bot className="w-6 h-6 text-primary" />
                     </div>
                   )}
                   
                   <div className={`
                     max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed
                     ${msg.role === 'user' 
                       ? 'bg-primary text-primary-foreground rounded-tr-none' 
                       : 'bg-white/10 text-foreground rounded-tl-none border border-white/5'}
                   `}>
                     {msg.content}
                   </div>

                   {msg.role === 'user' && (
                     <div className="w-10 h-10 rounded-full bg-secondary border border-white/10 flex items-center justify-center shrink-0">
                       {user?.profileImageUrl ? (
                          <img src={user.profileImageUrl} className="w-full h-full rounded-full" />
                       ) : (
                          <User className="w-6 h-6 text-muted-foreground" />
                       )}
                     </div>
                   )}
                 </motion.div>
               ))}
               {isLoading && (
                 <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4">
                   <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/50 flex items-center justify-center">
                     <Bot className="w-6 h-6 text-primary" />
                   </div>
                   <div className="bg-white/5 rounded-2xl p-4 rounded-tl-none border border-white/5 flex items-center gap-2">
                     <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                     <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                     <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                   </div>
                 </motion.div>
               )}
             </AnimatePresence>
          </div>

          {/* Input Area */}
          <div className="p-4 bg-black/20 border-t border-white/10">
            <form onSubmit={handleSend} className="flex gap-4">
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about analysis results..."
                className="bg-white/5 border-white/10 focus:border-primary/50 h-12"
              />
              <Button type="submit" size="icon" className="h-12 w-12 bg-primary text-primary-foreground hover:bg-primary/90" disabled={isLoading || !input.trim()}>
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </div>
        </Card>
      </div>
    </Layout>
  );
}
