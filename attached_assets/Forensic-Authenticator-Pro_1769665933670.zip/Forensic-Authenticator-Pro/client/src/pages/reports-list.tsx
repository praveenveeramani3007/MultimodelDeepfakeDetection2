import { Layout } from "@/components/layout";
import { useReports } from "@/hooks/use-reports";
import { Link } from "wouter";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Loader2, Filter } from "lucide-react";
import { useState } from "react";

export default function ReportsList() {
  const { data: reports, isLoading } = useReports();
  const [search, setSearch] = useState("");

  const filteredReports = reports?.filter(r => 
    r.title.toLowerCase().includes(search.toLowerCase()) ||
    r.id.toString().includes(search)
  );

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-white text-glow">Archives</h1>
            <p className="text-muted-foreground">Secure repository of all past forensic investigations.</p>
          </div>
          
          <div className="flex gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search case ID or title..." 
                className="pl-9 bg-white/5 border-white/10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Button variant="outline" className="border-white/10"><Filter className="w-4 h-4" /></Button>
          </div>
        </div>

        <div className="rounded-xl border border-white/10 overflow-hidden glass-panel">
          <Table>
            <TableHeader className="bg-white/5">
              <TableRow className="border-white/10 hover:bg-transparent">
                <TableHead className="font-bold text-primary">Case ID</TableHead>
                <TableHead className="font-bold text-primary">Title</TableHead>
                <TableHead className="font-bold text-primary">Type</TableHead>
                <TableHead className="font-bold text-primary">Status</TableHead>
                <TableHead className="font-bold text-primary">Verdict</TableHead>
                <TableHead className="font-bold text-primary text-right">Date</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-32 text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
                  </TableCell>
                </TableRow>
              ) : filteredReports && filteredReports.length > 0 ? (
                filteredReports.map((report) => (
                  <TableRow key={report.id} className="border-white/5 hover:bg-white/5 transition-colors group">
                    <TableCell className="font-mono text-muted-foreground">#{report.id.toString().padStart(4,'0')}</TableCell>
                    <TableCell className="font-medium text-foreground">{report.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="uppercase border-white/20 text-xs">
                        {report.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          report.status === 'completed' ? 'bg-green-500 shadow-[0_0_5px_#22c55e]' : 
                          report.status === 'processing' ? 'bg-yellow-500 animate-pulse' : 'bg-gray-500'
                        }`} />
                        <span className="capitalize text-sm">{report.status}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {report.fakeProbability ? (
                         <span className={`font-bold ${report.fakeProbability > 50 ? 'text-red-400' : 'text-green-400'}`}>
                           {report.fakeProbability > 50 ? 'FAKE' : 'REAL'} ({report.fakeProbability}%)
                         </span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground text-sm">
                      {new Date(report.createdAt!).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" asChild className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <Link href={`/reports/${report.id}`}>View</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                    No reports found matching your criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </Layout>
  );
}
