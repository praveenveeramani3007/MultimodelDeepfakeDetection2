import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ShieldCheck, Lock, Activity, ArrowRight, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden flex flex-col relative">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/10 blur-[120px] rounded-full opacity-50 pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-[800px] h-[600px] bg-accent/5 blur-[100px] rounded-full opacity-30 pointer-events-none" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px] opacity-20 pointer-events-none" />
      </div>

      <nav className="relative z-20 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-8 h-8 text-primary" />
          <span className="font-display font-bold text-xl tracking-wider text-white">TRUTHSEEKER</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Capabilities</a>
          <a href="#security" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Security</a>
        </div>
        <a href="/api/login">
          <Button className="bg-white/10 hover:bg-white/20 text-white border border-white/10 backdrop-blur-md">
            Authorized Access
          </Button>
        </a>
      </nav>

      <main className="flex-1 flex flex-col items-center justify-center text-center px-4 relative z-10 py-20">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6 max-w-4xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-widest mb-4">
            <Activity className="w-3 h-3" />
            System Operational • v2.4.0
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight">
            Advanced <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600 text-glow">Forensic</span><br />
            Media Analysis
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Government-grade deepfake detection and artifact verification platform using state-of-the-art neural networks.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <a href="/api/login">
              <Button size="lg" className="h-14 px-8 text-lg bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_30px_rgba(6,182,212,0.4)] font-bold rounded-full">
                Enter Dashboard <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </a>
            <Button variant="outline" size="lg" className="h-14 px-8 text-lg border-white/10 hover:bg-white/5 rounded-full backdrop-blur-md">
              System Status
            </Button>
          </div>
        </motion.div>

        {/* Floating Cards Effect */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto text-left">
          {[
            { 
              icon: Lock, 
              title: "Chain of Custody", 
              desc: "Immutable audit logs for every analysis step ensuring court admissibility." 
            },
            { 
              icon: Activity, 
              title: "Neural Analysis", 
              desc: "Multi-layered GAN detection for video, audio, and image artifacts." 
            },
            { 
              icon: ShieldCheck, 
              title: "Secure Infrastructure", 
              desc: "Military-grade encryption for all stored evidence and report data." 
            }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + (i * 0.1) }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:border-primary/30 transition-colors group"
            >
              <item.icon className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="font-display font-bold text-lg mb-2">{item.title}</h3>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </main>

      <footer className="relative z-20 border-t border-white/5 py-8 text-center text-sm text-muted-foreground">
        <p>&copy; 2025 TruthSeeker Labs • Official Government Use Only</p>
      </footer>
    </div>
  );
}
